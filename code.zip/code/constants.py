TotalNodes = 5 # Total number of nodes in the network
Z = 20 # %percentage of nodes that are slow
Ttx = 1 # mean for interarrival time of Transactions in seconds
Tk = 4 # mean for interarrival time of Blocks in seconds
simTime = 60 # time in seconds, after which simulation ends and analysis are shown
enableLiveTransactionPrinting = True # prints live transactions as it occurs
enableAnalysis = True # shows network graph and blockchains at each node at end


