import simpy
import network
import node

env = simpy.Environment()
mynetwork = network.Network(env)
# peers = mynetwork.nodes
for node in mynetwork.nodes:
    env.process(node.run())
env.run(until=20)


def doAnalysis(network):
    for node in network.nodes:
        print("--------------------------")
        node.printNode()
        #node.printTxn()

        node.blockchain.chain.printTree(node.id)
        # print the longest chain
        print('[ ', end="")
        for block in node.blockchain.getLongestChain():
            print(block.id, ",", end="")
        print(" ]")


doAnalysis(mynetwork)
